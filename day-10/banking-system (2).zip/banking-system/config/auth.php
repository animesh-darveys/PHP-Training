<?php
session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

require_once BASE_PATH . '/config/db.php';

if (empty($_SESSION['userid']) || empty($_SESSION['role'])) {
    header('Location: ' . (defined('LOGIN_REDIRECT') ? LOGIN_REDIRECT : '/login.php'));
    exit;
}