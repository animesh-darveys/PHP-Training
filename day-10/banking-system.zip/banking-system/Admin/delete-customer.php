<?php 
echo "Delete Customer";