<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Banking System - Create Customer</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="card shadow-sm" style="width: 100%; max-width: 500px;">
        <div class="card-body p-4">

            <h3 class="text-center mb-4">Create Customer</h3>

            <!-- action="create-customers.php" method="POST" -->
            <form action="create-customers.php" method="POST">

                <!-- Customer ID: not a form field - auto-assigned as FK after Users record is created -->
                <!-- Account Number: not a form field - auto-generate on the PHP side (e.g. random/sequential unique number) -->

                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" id="phone" name="phone" pattern="[0-9]{10}" placeholder="10-digit number" required>
                </div>

                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="dob" class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="dob" name="dob" required>
                </div>

                <div class="mb-3">
                    <label for="account_type" class="form-label">Account Type</label>
                    <select class="form-select" id="account_type" name="account_type" required>
                        <option value="" selected disabled>Select account type</option>
                        <option value="savings">Savings</option>
                        <option value="current">Current</option>
                    </select>
                </div>

                <!-- Status: not a form field - default to 'active' in DB on insert -->
                <!-- Created Date: not a form field - use NOW() / CURRENT_TIMESTAMP in the insert query -->

                <!-- CSRF token hidden field -->
                <input type="hidden" name="csrf_token" value="">

                <button type="submit" class="btn btn-primary w-100">Create Customer</button>

            </form>

        </div>
    </div>
</div>

</body>
</html>