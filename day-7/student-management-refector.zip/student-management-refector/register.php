<?php

require_once './config/auth.php';
require_once './config/database.php';
require_once './classes/Student.php';
if($_SESSION['role'] === 'student'){
    header('Location: login.php');
    exit;
}
$studentName = '';
$studentEmail = '';
$studentDOB = '';
$studentCourse = '';
$studentPassword='';
$role='';
$errors = [];

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrfToken = $_POST['csrf_token'] ?? '';

    if (
        empty($csrfToken) ||
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $csrfToken)
    ) {
        die('Invalid CSRF token.');
    }

    $studentName = trim($_POST['name'] ?? '');
    $studentEmail = trim($_POST['email'] ?? '');
    $studentDOB = trim($_POST['dob'] ?? '');
    $studentCourse = trim($_POST['course'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $photo = $_FILES['photo'] ?? null;
    $role = trim($_POST['role'] ?? '');
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $database = new Database();
    $conn = $database->getConnection();

    $student = new Student(
        $conn,
        $studentName,
        $studentEmail,
        $studentDOB,
        $studentCourse,
        $photo,
        $role,
        $hashedPassword,
    );

    $errors = $student->validate(true);

    if (empty($errors)) {

        $profilePhoto = $student->uploadPhoto();

        if ($profilePhoto === null) {
            $errors['studentImage'] = 'Photo upload failed.';
        } else {

            try {

                if ($student->create($profilePhoto)) {

                    $_SESSION['message'] = 'Student inserted successfully.';
                    header('Location: student_list.php');
                    exit;
                }

                $errors['database'] = 'Student could not be inserted.';

            } catch (PDOException $e) {

                $errors['database'] = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand">Student Management System</span>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
</nav>

<div class="container" style="max-width: 600px;">

    <div class="card">
        <div class="card-body">

            <h4 class="card-title mb-3">Register Admin/Student</h4>

            <?php if (isset($errors['database'])): ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($errors['database']) ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
                >
                <div class="mb-3">
                    <label class="form-label">Role</label>

                    <select class="form-select" name="role">
                        <option value="">Select Role</option>

                        <option value="Admin"
                            <?= $role === 'admin' ? 'selected' : '' ?>>
                            Admin
                        </option>

                        <option value="student"
                            <?= $role === 'student' ? 'selected' : '' ?>>
                            Student
                        </option>
                    </select>

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentCourse'] ?? '') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Full Name</label>

                    <input
                        type="text"
                        class="form-control"
                        name="name"
                        value="<?= htmlspecialchars($studentName) ?>"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentName'] ?? '') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>

                    <input
                        type="email"
                        class="form-control"
                        name="email"
                        value="<?= htmlspecialchars($studentEmail) ?>"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentEmail'] ?? '') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Date of Birth</label>

                    <input
                        type="date"
                        class="form-control"
                        name="dob"
                        value="<?= htmlspecialchars($studentDOB) ?>"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentDOB'] ?? '') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Course</label>

                    <select class="form-select" name="course">
                        <option value="">Select Course</option>

                        <option value="web-development"
                            <?= $studentCourse === 'web-development' ? 'selected' : '' ?>>
                            Web Development
                        </option>

                        <option value="data-science"
                            <?= $studentCourse === 'data-science' ? 'selected' : '' ?>>
                            Data Science
                        </option>

                        <option value="cyber-security"
                            <?= $studentCourse === 'cyber-security' ? 'selected' : '' ?>>
                            Cyber Security
                        </option>
                    </select>

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentCourse'] ?? '') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Profile Photo</label>

                    <input
                        type="file"
                        class="form-control"
                        name="photo"
                        accept="image/jpeg,image/png,image/webp"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentImage'] ?? '') ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label" required>Password</label>
                    <input type="password" name="password" id="password" class="form-control">

                    <div class="invalid-feedback d-block text-danger small">
                        <?= htmlspecialchars($errors["password"] ?? "") ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    Register Student
                </button>

            </form>

        </div>
    </div>

    <p class="text-center mt-3">
        <a href="student_list.php">View all students</a>
    </p>

</div>

</body>
</html>
