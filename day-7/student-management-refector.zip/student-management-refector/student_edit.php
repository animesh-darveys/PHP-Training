<?php

require_once './config/auth.php';
require_once './config/database.php';
require_once './classes/Student.php';

$database = new Database();
$conn = $database->getConnection();

if (isset($_GET['id'])) {
    $studentId = (int) $_GET['id'];
} elseif (isset($_POST['student_id'])) {
    $studentId = (int) $_POST['student_id'];
}

if ($studentId <= 0) {
    die('Invalid student ID.');
}

$student = new Student($conn);

$result = $student->findById($studentId);

if (!$result) {
    die('Student not found.');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $course = trim($_POST['course'] ?? '');
    $photo = $_FILES['photo'] ?? null;

    $student = new Student(
        $conn,
        $name,
        $email,
        $dob,
        $course,
        $photo
    );

    $errors = $student->validate(false);

    if (empty($errors)) {

        $profilePhoto = $student->uploadPhoto();

        try {

            if ($student->update($studentId, $profilePhoto)) {

                $_SESSION['message'] = 'Student updated successfully.';
                header('Location: student_list.php');
                exit;
            }

            $errors['database'] = 'Student could not be updated.';

        } catch (PDOException $e) {

            $errors['database'] = 'Database error: ' . $e->getMessage();
        }
    }

    $result->full_name = $name;
    $result->email = $email;
    $result->dob = $dob;
    $result->course = $course;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand">Student Management System</span>
    </div>
</nav>

<div class="container" style="max-width: 600px;">

    <div class="card">

        <div class="card-body">

            <h4 class="card-title mb-3">Edit Student</h4>

            <?php if (isset($errors['database'])): ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($errors['database']) ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">

                <input
                    type="hidden"
                    name="student_id"
                    value="<?= (int) $result->id ?>"
                >

                <div class="mb-3 text-center">

                    <img
                        src="<?= htmlspecialchars($result->profile_photo) ?>"
                        width="80"
                        height="80"
                        style="object-fit: cover;"
                        class="rounded-circle"
                        alt="Student photo"
                    >

                </div>

                <div class="mb-3">

                    <label class="form-label">Full Name</label>

                    <input
                        type="text"
                        class="form-control"
                        name="name"
                        value="<?= htmlspecialchars($result->full_name) ?>"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentName'] ?? '') ?>
                    </div>

                </div>

                <div class="mb-3">

                    <label class="form-label">Email</label>

                    <input
                        type="email"
                        class="form-control"
                        name="email"
                        value="<?= htmlspecialchars($result->email) ?>"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentEmail'] ?? '') ?>
                    </div>

                </div>

                <div class="mb-3">

                    <label class="form-label">Date of Birth</label>

                    <input
                        type="date"
                        class="form-control"
                        name="dob"
                        value="<?= htmlspecialchars($result->dob) ?>"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentDOB'] ?? '') ?>
                    </div>

                </div>

                <div class="mb-3">

                    <label class="form-label">Course</label>

                    <select class="form-select" name="course">

                        <option value="web-development"
                            <?= $result->course === 'web-development' ? 'selected' : '' ?>>
                            Web Development
                        </option>

                        <option value="data-science"
                            <?= $result->course === 'data-science' ? 'selected' : '' ?>>
                            Data Science
                        </option>

                        <option value="cyber-security"
                            <?= $result->course === 'cyber-security' ? 'selected' : '' ?>>
                            Cyber Security
                        </option>

                    </select>

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentCourse'] ?? '') ?>
                    </div>

                </div>

                <div class="mb-3">

                    <label class="form-label">
                        Replace Photo <small>(optional)</small>
                    </label>

                    <input
                        type="file"
                        class="form-control"
                        name="photo"
                        accept="image/jpeg,image/png,image/webp"
                    >

                    <div class="text-danger small">
                        <?= htmlspecialchars($errors['studentImage'] ?? '') ?>
                    </div>

                </div>

                <button type="submit" class="btn btn-primary w-100">
                    Save Changes
                </button>

            </form>

        </div>

    </div>

    <p class="text-center mt-3">
        <a href="student_list.php">Back to list</a>
    </p>

</div>

</body>
</html>
